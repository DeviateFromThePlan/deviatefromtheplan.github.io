// ==UserScript==
// @name         WME Mouse Coordinate Grabber
// @namespace    https://github.com/DeviateFromThePlan
// @version      2026.09.22.01
// @description  Press 'Ctrl+.' to grab mouse coordinates on the Waze Map Editor without additional clicks
// @author       ChatGPT & DeviateFromThePlan
// @match        *://*.waze.com/*editor*
// @exclude      *://*.waze.com/user/editor*
// @grant        GM_setClipboard
// @grant        unsafeWindow
// @downloadURL  https://github.com/DeviateFromThePlan/WME-Mouse-Coordinate-Grabber/releases/latest/download/WME-MCG.user.js
// @updateURL    https://github.com/DeviateFromThePlan/WME-Mouse-Coordinate-Grabber/releases/latest/download/WME-MCG.user.js
// ==/UserScript==

(function() {
    'use strict';

    const SCRIPT_ID = 'wme-mouse-coordinate-grabber';
    const SCRIPT_NAME = 'WME Mouse Coordinate Grabber';
    const STORAGE_KEY = 'wme-mcg-shortcut';
    // Ctrl (or Cmd on Mac) + '.'. Matched on the physical key (event.code) so it
    // works regardless of keyboard layout or whether Shift changes the character
    const DEFAULT_SHORTCUT = { ctrl: true, alt: false, shift: false, code: 'Period', label: '.' };
    const MODIFIER_CODES = ['ControlLeft', 'ControlRight', 'AltLeft', 'AltRight', 'ShiftLeft', 'ShiftRight', 'MetaLeft', 'MetaRight'];

    let sdk;
    // Last known pointer position over the map in WGS84, or null when the pointer is off the map
    let lastMousePosition = null;
    let shortcut = loadShortcut();
    let isRecordingShortcut = false;
    let shortcutDisplay;
    let changeButton;

    function loadShortcut() {
        try {
            const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
            if (saved && typeof saved.code === 'string') {
                return saved;
            }
        } catch (e) {
            // Missing, corrupt or blocked storage: use the default
        }
        return { ...DEFAULT_SHORTCUT };
    }

    function saveShortcut(newShortcut) {
        shortcut = newShortcut;
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(newShortcut));
        } catch (e) {
            console.warn(`${SCRIPT_NAME}: Could not save shortcut`, e);
        }
        updateShortcutDisplay();
    }

    function describeShortcut(s) {
        const parts = [];
        if (s.ctrl) parts.push('Ctrl');
        if (s.alt) parts.push('Alt');
        if (s.shift) parts.push('Shift');
        parts.push(s.label);
        return parts.join(' + ');
    }

    function updateShortcutDisplay() {
        if (!shortcutDisplay) {
            return;
        }
        shortcutDisplay.textContent = isRecordingShortcut ? 'Press the new key combination… (Esc to cancel)' : describeShortcut(shortcut);
        changeButton.textContent = isRecordingShortcut ? 'Cancel' : 'Change';
    }

    function isTypingInField(target) {
        return target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT|WZ-TEXT-INPUT|WZ-TEXTAREA)$/.test(target.tagName));
    }

    function matchesShortcut(e) {
        return e.code === shortcut.code
            && (e.ctrlKey || e.metaKey) === shortcut.ctrl
            && e.altKey === shortcut.alt
            && e.shiftKey === shortcut.shift;
    }

    function onKeyDown(e) {
        if (isRecordingShortcut) {
            if (MODIFIER_CODES.includes(e.code)) {
                return; // Wait for the actual key
            }
            e.preventDefault();
            e.stopPropagation();
            isRecordingShortcut = false;
            if (e.code === 'Escape') {
                updateShortcutDisplay();
                return;
            }
            saveShortcut({
                ctrl: e.ctrlKey || e.metaKey,
                alt: e.altKey,
                shift: e.shiftKey,
                code: e.code,
                label: e.key.length === 1 ? e.key.toUpperCase() : e.key,
            });
            return;
        }

        if (e.repeat || !matchesShortcut(e)) {
            return;
        }
        // Don't hijack plain keys while the user is typing in a text box
        if (!shortcut.ctrl && !shortcut.alt && isTypingInField(e.target)) {
            return;
        }
        e.preventDefault();
        e.stopPropagation();
        grabCoordinates();
    }

    function copyCoordinatesToClipboard(coordinates) {
        GM_setClipboard(coordinates, 'text');
        console.log(`${SCRIPT_NAME}: Coordinates copied to clipboard: ${coordinates}`);
    }

    function showToast(message) {
        const toastContainer = document.createElement('div');
        toastContainer.style.position = 'fixed';

        // The header may not exist (layout changes, beta WME), so fall back to 0
        const appHead = document.getElementById('app-head');
        const totalTopOffset = 20 + (appHead ? appHead.offsetHeight : 0);
        toastContainer.style.top = `${totalTopOffset}px`;

        toastContainer.style.left = '50%';
        toastContainer.style.transform = 'translateX(-50%)';
        toastContainer.style.zIndex = '10000';
        toastContainer.style.backgroundColor = '#fff';
        toastContainer.style.color = '#333';
        toastContainer.style.padding = '10px';
        toastContainer.style.borderRadius = '5px';
        toastContainer.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.3)';
        toastContainer.style.pointerEvents = 'none';
        toastContainer.style.opacity = '0';
        toastContainer.style.transition = 'opacity 0.5s ease-in-out';

        toastContainer.textContent = message;

        document.body.appendChild(toastContainer);

        // Trigger a reflow to apply styles and initiate the fade-in animation
        toastContainer.offsetHeight;

        // Show the toast
        toastContainer.style.opacity = '1';

        // Automatically hide after 5 seconds
        setTimeout(() => {
            // Initiate the fade-out animation
            toastContainer.style.opacity = '0';

            // Remove the element from the DOM after the animation completes
            setTimeout(() => {
                toastContainer.remove();
            }, 500);
        }, 5000);
    }

    function onMapMouseMove(event) {
        // The SDK event carries the pointer position in WGS84; fall back to
        // converting the pixel position if lon/lat are ever missing
        if (event && typeof event.lat === 'number' && typeof event.lon === 'number') {
            lastMousePosition = { lat: event.lat, lon: event.lon };
        } else if (event && typeof event.x === 'number' && typeof event.y === 'number') {
            lastMousePosition = sdk.Map.getLonLatFromPixel({ x: event.x, y: event.y });
        }
    }

    function onMapMouseOut() {
        lastMousePosition = null;
    }

    function grabCoordinates() {
        if (!lastMousePosition) {
            showToast('Move the mouse over the map to grab coordinates');
            return;
        }

        // Format and copy coordinates to clipboard
        const formattedCoordinates = `${lastMousePosition.lat.toFixed(6)}, ${lastMousePosition.lon.toFixed(6)}`;
        copyCoordinatesToClipboard(formattedCoordinates);

        // Display toast notification
        showToast(`Coordinates copied to clipboard: ${formattedCoordinates}`);
    }

    function buildSettingsTab() {
        sdk.Sidebar.registerScriptTab().then(({ tabLabel, tabPane }) => {
            tabLabel.textContent = 'MCG';
            tabLabel.title = SCRIPT_NAME;

            tabPane.innerHTML = `
                <div style="padding: 8px;">
                    <h4 style="margin-top: 0;">${SCRIPT_NAME}</h4>
                    <p>Press the shortcut while the mouse is over the map to copy its coordinates.</p>
                    <div style="margin-bottom: 8px;">
                        <b>Shortcut:</b> <span id="wme-mcg-shortcut-display"></span>
                    </div>
                    <button type="button" id="wme-mcg-change">Change</button>
                    <button type="button" id="wme-mcg-reset">Reset to Ctrl + .</button>
                    <p style="margin-top: 12px; color: #888;">v${GM_info.script.version}</p>
                </div>`;

            shortcutDisplay = tabPane.querySelector('#wme-mcg-shortcut-display');
            changeButton = tabPane.querySelector('#wme-mcg-change');

            changeButton.addEventListener('click', () => {
                isRecordingShortcut = !isRecordingShortcut;
                changeButton.blur(); // So Space/Enter as a shortcut doesn't re-click the button
                updateShortcutDisplay();
            });
            tabPane.querySelector('#wme-mcg-reset').addEventListener('click', () => {
                isRecordingShortcut = false;
                saveShortcut({ ...DEFAULT_SHORTCUT });
            });

            updateShortcutDisplay();
        });
    }

    function initScript() {
        sdk = unsafeWindow.getWmeSdk({ scriptId: SCRIPT_ID, scriptName: SCRIPT_NAME });

        sdk.Events.once({ eventName: 'wme-ready' }).then(() => {
            // Track the pointer continuously so the shortcut can copy instantly,
            // with no need to move the mouse after pressing it
            sdk.Events.on({ eventName: 'wme-map-mouse-move', eventHandler: onMapMouseMove });
            sdk.Events.on({ eventName: 'wme-map-mouse-out', eventHandler: onMapMouseOut });

            // Capture phase so the shortcut is handled before WME's own key handlers
            window.addEventListener('keydown', onKeyDown, true);

            buildSettingsTab();
            console.log(`${SCRIPT_NAME}: Initialized with shortcut ${describeShortcut(shortcut)}`);
        });
    }

    unsafeWindow.SDK_INITIALIZED.then(initScript);
})();
